#ifndef MYSQRT_H_
#define MYSQRT_H_

double mysqrt(double inputValue);

#endif /* MYSQRT_H_ */
