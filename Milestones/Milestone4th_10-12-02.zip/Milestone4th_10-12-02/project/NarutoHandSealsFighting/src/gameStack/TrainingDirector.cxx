/*
 ******************************************************
 * NAME:
 * TrainingDirector.cxx
 ******************************************************
 * DESCRIPTION:
 *
 ******************************************************
 *	Created on: Dec 1, 2010
 ******************************************************
 *  Author: Michele Tamburini
 *******************************************************
 *
 */

#include "TrainingDirector.h"

TrainingDirector::TrainingDirector() {
	// TODO Auto-generated constructor stub

}

TrainingDirector::~TrainingDirector() {
	// TODO Auto-generated destructor stub
}
