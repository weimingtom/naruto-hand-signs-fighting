/*
 ******************************************************
 * NAME:
 * GameStack.h
 ******************************************************
 * DESCRIPTION:
 *
 ******************************************************
 *	Created on: Nov 30, 2010
 ******************************************************
 *  Author: Michele Tamburini
 *******************************************************
 *
 */

#ifndef GAMESTACK_H_
#define GAMESTACK_H_

#include "GameMachine.h"
#include "FactoryGameMachine.h"

#endif /* GAMESTACK_H_ */
