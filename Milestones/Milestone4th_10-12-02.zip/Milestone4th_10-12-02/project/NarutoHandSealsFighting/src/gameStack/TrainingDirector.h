/*
 ******************************************************
 * NAME:
 * TrainingDirector.h
 ******************************************************
 * DESCRIPTION:
 *
 ******************************************************
 *	Created on: Dec 1, 2010
 ******************************************************
 *  Author: Michele Tamburini
 *******************************************************
 *
 */

#ifndef TRAININGDIRECTOR_H_
#define TRAININGDIRECTOR_H_

class TrainingDirector {
public:
	TrainingDirector();
	virtual ~TrainingDirector();
};

#endif /* TRAININGDIRECTOR_H_ */
