/*
 ******************************************************
 * NAME:
 * OptionsMenu.cxx
 ******************************************************
 * DESCRIPTION:
 *
 ******************************************************
 *	Created on: Nov 25, 2010
 ******************************************************
 *  Author: Michele Tamburini
 *******************************************************
 *
 */

#include "OptionsMenu.h"
#include <iostream>

void OptionsMenu::displayMenuElement(){
	elementGraphic->display();
}
