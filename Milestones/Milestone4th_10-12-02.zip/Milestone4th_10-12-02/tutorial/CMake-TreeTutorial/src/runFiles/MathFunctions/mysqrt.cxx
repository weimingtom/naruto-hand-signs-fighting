#include <math.h>
#include <stdio.h>
#include "mysqrt.h"

double mysqrt(double inputValue){
	printf("using my sqrt library! \n");
	return sqrt(inputValue);
}

