/*
 * Move.h
 *
 *  Created on: Nov 13, 2010
 *      Author: michele
 */

#ifndef MOVE_H_
#define MOVE_H_

class Move{

};

#endif /* MOVE_H_ */
