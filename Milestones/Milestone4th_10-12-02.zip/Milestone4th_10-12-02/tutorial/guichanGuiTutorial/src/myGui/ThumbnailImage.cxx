/*
 ******************************************************
 * NAME:
 * ThumbnailImage.cxx
 ******************************************************
 * DESCRIPTION:
 *
 ******************************************************
 *	Created on: Nov 28, 2010
 ******************************************************
 *  Author: Michele Tamburini
 *******************************************************
 *
 */

#include "ThumbnailImage.h"

ThumbnailImage::ThumbnailImage(int x, int y) : AbstractGUIObject(x,y) {
	// TODO Auto-generated constructor stub

}

ThumbnailImage::~ThumbnailImage() {
	// TODO Auto-generated destructor stub
}
