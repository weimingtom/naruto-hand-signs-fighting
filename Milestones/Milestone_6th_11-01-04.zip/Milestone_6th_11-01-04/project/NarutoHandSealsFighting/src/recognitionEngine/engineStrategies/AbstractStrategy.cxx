/*
 ******************************************************
 * NAME:
 * AbstractStrategy.cxx
 ******************************************************
 * DESCRIPTION:
 *
 ******************************************************
 *	Created on: Dec 7, 2010
 ******************************************************
 *  Author: Michele Tamburini
 *******************************************************
 *
 */

#include "AbstractStrategy.h"

AbstractStrategy::AbstractStrategy(ModulesPool* p) {
	rePool = p;
	strategyName = "";
}

AbstractStrategy::~AbstractStrategy() {
	// TODO Auto-generated destructor stub
}
