README.txt

 Created on: Nov 23, 2010
     Author: michele

In order to build all the templates from the default location 
	"../../src/templatesCreationSection/sourceRawImages"
run the script:
		templateCreator.sh
It will generate all the template images in B/W 
into the folder: 
		"../movesTemplates"