/*
 * main-NHSF.cxx
 *
 *  Created on: Nov 19, 2010
 *      Author: michele
 */

#include "recognitionEngine/RecognitionEngine.h"

int main(int argc, char* argv[]){

	return 0;
}
